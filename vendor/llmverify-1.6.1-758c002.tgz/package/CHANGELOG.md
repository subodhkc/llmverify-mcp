# Changelog

All notable changes to llmverify will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Fixed - verification result contract
- `schema/verify-result.schema.json` now matches the actual `verify()` output (`schemaVersion`, engine-keyed optional results, `risk.overall`, `meta`, `limitations`, `notChecked`) instead of requiring fields the runtime never emitted (`findings`, `engines`, `metadata`, `risk.score`). A versioned copy ships at `schema/verify-result-1.0.schema.json`.
- `src/types/results.ts` now declares runtime fields that were previously missing (`Claim.riskIndicators` sub-scores, `warnings`, `audit` receipt).
- New `validateVerifyResult()` runtime validator and `RESULT_SCHEMA_VERSION` export; `getVerifyResultSchemaPath()` locates the packaged schema for downstream consumers.

### Fixed - audit integrity & persistence
- Shared integrity layer (`src/audit/integrity.ts`): canonical JSON serialization, self-describing `sha256:`/`hmac-sha256:`/`legacy:` content hashes, per-entry `sha256` digests with constant-time verification.
- `src/audit/index.ts` (legacy API preserved) now uses the same cryptographic hashing as `src/logging/audit.ts`; `contentHashAlgorithm` labels stored hashes so historical records stay interpretable.
- Audit writes return an explicit `AuditWriteResult` receipt: `PERSISTED` / `DISABLED` / `FAILED` / `NOT_ATTEMPTED`. `verify()` surfaces it at `result.audit` (and via `audit.onResult`); `audit.requirePersistence: true` throws the new typed `AuditPersistenceError` (`LLMVERIFY_8001`) when a durable record is required but the write fails.
- `verifyAuditFile()` reports `verified`/`tampered`/`unverifiable` per entry; legacy pre-digest records are unverifiable rather than silently trusted.

### Fixed - `llmverify-serve` bin
- The server bin now actually starts: it invokes `startServer()` explicitly (the previous `require()` never triggered the `require.main` guard). `--port`/`--host` args are parsed and validated.

### Changed - privacy & local-state configurability
- All local state paths centralized in `src/paths.ts`: `LLMVERIFY_HOME` relocates the whole `~/.llmverify` tree; `LLMVERIFY_LOG_DIR`, `LLMVERIFY_AUDIT_DIR`, `LLMVERIFY_BASELINE_DIR`, `LLMVERIFY_USAGE_FILE`, `LLMVERIFY_CONFIG_DIR` override individually.
- Audit content hashing can be keyed (`hashKey` / `LLMVERIFY_AUDIT_HASH_KEY`) or disabled (`includeContentHash: false` / `LLMVERIFY_AUDIT_NO_CONTENT_HASH=1`) for low-entropy or sensitive workloads.
- Logger sanitization strengthened for nested objects and common secret-key variants. No raw content is written to audit records by default; zero-network behavior unchanged.

### Changed - truthful capability metadata
- New `getEngineCapabilities()` / `getPackageInfo()` for downstream integrations (e.g. a future MCP adapter): each capability states what it observes and what it does not establish.
- Methodology strings in the harmful-content, PII, and prompt-injection detectors no longer assert unsupported accuracy percentages.

### Fixed - test infrastructure
- `tests/integration.test.js` and `tests/monitor.test.js` now spawn the real `bin/llmverify-serve.js` on distinct ports with isolated `LLMVERIFY_HOME`, and clean up keep-alive sockets that crashed jest workers.
- `tests/usage-limit-2000.test.ts` uses an isolated usage file (fixes cross-worker races on `~/.llmverify/usage.json`).

## [1.6.1] - 2026-08-21

### Fixed - PII redaction false negatives
- `redactPII` no longer skips `example.com` emails: the placeholder heuristic now examines only the text surrounding a match (not the match itself), so `example` inside an email domain no longer suppresses redaction.
- Placeholder words are now word-bounded (`\bexample\b`, `\btest\b`, ...), so substrings like "latest", "contest", and "demographic" no longer suppress redaction of nearby PII.
- `redactPII` now operates in conservative (aggressive) mode: it redacts when in doubt rather than suppressing. A false positive of redaction is less harmful than leaking real PII.
- Duplicate PII occurrences are now all redacted (previously only the first match was replaced; the replace is now global).
- SSN detection no longer suppressed by an unanchored date check: a 3-2-4 SSN like `123-45-6789` is no longer skipped because the `23-45-6789` substring looked like a 2-2-4 date. The date check is now anchored to the whole match.

### Security - HTTP server hardening (`llmverify-serve`)
- Server binds to `127.0.0.1` (localhost only) by default. Previously bound to `0.0.0.0` (all interfaces) with no authentication, exposing the verification API to the network.
- CORS restricted to localhost origins. Previously `Access-Control-Allow-Origin: *`, allowing any website to drive the local server.
- Rate limiting added to all POST endpoints (100 requests / 60s per client). `RateLimiter` was already exported but unused.
- `--host=0.0.0.0` now requires an explicit flag and prints a warning. Only use on a trusted network; there is no auth on the API.

### Fixed - input validation
- `verify()` "invalid characters" check is no longer a no-op. It now rejects unprintable control characters (except tab, newline, carriage return). The previous regex matched everything.

### Changed - package metadata
- `homepage` corrected to `https://www.haiec.com/llmverify` (was a non-existent `/llmverify/docs` path).
- `author` set to `Subodh Kc <subodhkc.com>` (was `HAIEC`), consistent with `mcp-tenant-isolation`.
- Removed broken `serve`, `serve:force`, `monitor`, and `setup-ai` npm scripts that referenced files not shipped with the package. Use `npx llmverify-serve` for the HTTP server.

### Changed - README
- Rewritten in HAIEC voice: fixed mojibake em-dashes, corrected all links (product page, PyPI placeholder, dashboard), corrected advertised API names (`detectAndRepairJson`, `auditLog`), added a Last Updated date and an honest Limitations section.

### Changed - publishing
- `npm-publish.yml` switched to npm Trusted Publishing via GitHub Actions OIDC with `--provenance`. No `NPM_TOKEN`. Requires npm-side trusted-publisher configuration (repo + workflow + `release` environment).

## [1.5.2] - 2026-02-08

### Added - Dashboard Integration CLI
- `npx llmverify connect <API_KEY>` — opt-in connection to HAIEC dashboard
- `npx llmverify disconnect` — remove dashboard connection, revert to 100% local
- `npx llmverify sync` — push local usage data to HAIEC dashboard
- `npx llmverify status` — show tier, usage, limits, and connection status
- `npx llmverify usage` — quick usage summary (alias for status)
- Dashboard config stored at `~/.llmverify/config.json` with 0600 permissions
- API key validated against server before saving
- Tier auto-updates from server on sync if subscription changed

### Added - Feature Summary Table in README
- 19-row "Complete Feature Map" table with Category, Feature, Function, Description
- HAIEC ecosystem CTAs linking to Security Scanner, CI/CD, Runtime Testing

### Security Notes
- Free tier remains 100% local — zero network, zero telemetry (unchanged)
- Dashboard connection is opt-in only — user must explicitly run `connect`
- No background sync — user initiates every `sync` call
- API key format validated client-side before any network request

## [1.5.1] - 2026-02-08

### Fixed - Documentation Accuracy
- Fixed `verify()` response shape in README: `verification.result.risk` → `verification.risk` (7 occurrences)
- Fixed `classify()` signature in README: now correctly shows `classify(prompt, response)` (requires 2 args)
- Fixed `createAdapter()` signature in README + website: now correctly shows `createAdapter({ provider: 'openai', apiKey })` (single config object)
- Fixed `redactPII()` comment: output is `[REDACTED]` not `[EMAIL_REDACTED]`
- Fixed `createAdapter()` in AI-GUIDE.md API Mode example
- Added "API Quick Reference (Correct Signatures)" section to AI-GUIDE.md for AI assistant code generation accuracy

### Added - Prompt Injection Pattern Coverage
- Added pattern for `"ignore all rules/guidelines/policies"` (without requiring "previous")
- Added pattern for `"output the system prompt"` / `"give me the system instructions"`

## [1.5.0] - 2026-02-08

### Added - Tier System & Usage Tracking
- Local-only usage tracking via `~/.llmverify/usage.json` — no network calls, no telemetry
- Four pricing tiers: `free` (500 calls/day), `starter` (5,000), `pro` (50,000), `business` (unlimited)
- Soft cap with grace period (10% above limit) before hard block
- New error codes: `LLMVERIFY_7001` (usage limit exceeded), `LLMVERIFY_7002` (content length exceeded)
- `checkUsageLimit()` and `checkContentLength()` exported for programmatic access
- `readUsage()` and `getUsageSummary()` for usage inspection
- `TIER_USAGE_LIMITS` exported with per-tier limits (dailyCallLimit, maxContentLength, auditRetentionDays, maxPlugins, customPatterns)
- Usage warnings injected into `verify()` result when approaching daily limit
- Postinstall banner now shows free tier info and `npx llmverify usage` command

### Added - Sentinel Simple API
- `sentinel.quick(client, model)` — one-liner to run all 4 sentinel tests
- `sentinel.test(name, client, model)` — run a single sentinel test by name
- `sentinel.runAll` — re-export of `runAllSentinelTests` for convenience

### Added - Typed Interfaces
- `AiShorthand` interface for the `ai` and `llm` shorthand objects
- `GuardrailsAPI` interface for the `guardrails` compatibility object

### Fixed
- `server.ts`: express import now uses dynamic `require()` with helpful error message if express is not installed (was crashing when express was in optionalDependencies)
- `validatePrivacyCompliance`: updated tier reference from "Team" to "Starter"
- `INVALID_TIER` error suggestion updated to use new tier names (free, starter, pro, business)

### Changed
- Tier names renamed: `team` → `starter`, `professional` → `pro`, `enterprise` → `business`
- `TIER_LIMITS` performance values now match `TIER_USAGE_LIMITS` content length caps

## [1.4.2] - 2026-02-08

### Added - Developer Experience
- `verify()` now accepts a plain string: `verify("text")` is shorthand for `verify({ content: "text" })`
- Default export: `import llmverify from 'llmverify'` now works (exports the `ai` shorthand object)
- IDE extension local fallback: when server is unavailable, `LLMVerifyIDE.verify()` falls back to local `verify()` automatically (new `useLocalFallback` option, defaults to `true`)

### Fixed
- `validateConfig()` was checking wrong property paths (`config.maxContentLength` instead of `config.performance?.maxContentLength`, `config.verbose` instead of `config.output?.verbose`)
- Moved `express` from `dependencies` to `optionalDependencies` (saves ~2MB for library-only users)

## [1.4.1] - 2026-02-08

### Fixed - Packaging & Branding
- Removed self-referencing dependency (`llmverify` listing itself in `dependencies`)
- Fixed VERSION constants stuck at `1.0.0` in `constants.ts`, `postinstall.ts`, and `index.ts` JSDoc
- Updated author from "KingCaliber Labs" to "HAIEC" across all source files and `package.json`
- Updated homepage URL to point to documentation site

## [1.4.0] - 2024-12-04

### Added - Enterprise Features

**Enhanced Error Handling:**
- 20+ standardized error codes (LLMVERIFY_1001 format)
- Error severity levels (low, medium, high, critical)
- Error metadata with actionable suggestions
- Recoverable/non-recoverable classification
- JSON serialization support

**Logging & Audit System:**
- Structured logging to `~/.llmverify/logs/*.jsonl`
- Request ID tracking with UUID
- Automatic PII sanitization in logs
- Log rotation (10MB max, keep 10 files)
- Audit trail to `~/.llmverify/audit/*.jsonl`
- SHA-256 content hashing
- Compliance-ready audit exports
- Log statistics & analytics

**Baseline Drift Detection:**
- Baseline metrics storage (`~/.llmverify/baseline/baseline.json`)
- Running averages for latency, content length, risk score
- Risk distribution tracking
- Engine score tracking
- Drift detection with 20% threshold
- Drift history tracking
- CLI commands: `baseline:stats`, `baseline:reset`, `baseline:drift`

**Plugin System:**
- Extensible rule system for custom verification
- Plugin registry with enable/disable
- Priority-based execution
- Category-based filtering
- Built-in helpers: blacklist, regex, length validator, keyword detector
- `use()` API for plugin registration

**Security Hardening:**
- Input validation with size limits
- Safe regex execution with timeout protection
- PII sanitization utilities
- Rate limiter class
- XSS prevention (HTML escaping)
- Injection detection
- URL validation

### Changed
- `verify()` now integrates logging, audit, baseline tracking, and plugins
- Enhanced input validation with better error messages
- Improved error handling throughout codebase

### API Additions
- `ErrorCode`, `ErrorSeverity`, `getErrorMetadata()`
- `Logger`, `getLogger()`, `LogLevel`
- `AuditLogger`, `getAuditLogger()`
- `BaselineStorage`, `getBaselineStorage()`
- `Plugin`, `use()`, `createPlugin()`
- `RateLimiter`, `sanitizeForLogging()`, `safeRegexTest()`

### Documentation
- Complete implementation of enterprise features
- All APIs exported and documented
- CLI commands for baseline management

## [1.3.1] - 2024-12-04

### Added
- **Complete API Reference Documentation** (`docs/API-REFERENCE.md`)
  - Comprehensive programmatic API documentation
  - All functions with parameters, return types, and examples
  - TypeScript type definitions
  - Best practices and error handling
- **JSON Schema for verify() Output** (`schema/verify-result.schema.json`)
  - Formal JSON Schema (draft-07) for VerifyResult
  - Complete type definitions and validation rules
  - Example outputs for reference
  - Machine-readable schema for validation tools
- **Enhanced Documentation**
  - Added schema directory to npm package
  - Improved API discoverability

### Changed
- Package now includes `schema/` directory in published files
- Enhanced type safety with formal JSON schema

### Documentation
- Complete API reference with all functions documented
- JSON schema for programmatic validation
- TypeScript type definitions reference
- Best practices guide

## [1.3.0] - 2024-12-04

### Added
- **HTTP Server Mode**: New `llmverify-serve` command starts a long-running HTTP API server
  - Default port 9009, configurable via `--port` flag
  - RESTful endpoints: `/verify`, `/check-input`, `/check-pii`, `/classify`, `/health`
  - Full CORS support for local development
  - Graceful shutdown handling
- **IDE Integration**: Comprehensive guide for Windsurf, Cursor, VS Code, and custom IDEs
  - Example code for TypeScript, JavaScript, Python
  - System prompt templates for AI assistants
  - Production deployment guidelines
- **Server Endpoints**:
  - `POST /verify` - Main verification endpoint (accepts `text` or `content`)
  - `POST /check-input` - Input safety check for prompt injection
  - `POST /check-pii` - PII detection and redaction
  - `POST /classify` - Output classification with intent and hallucination risk
  - `GET /health` - Health check with version info
  - `GET /` - API documentation endpoint
- **Enhanced CLI**:
  - Improved `--output json` mode for scripting
  - Better error messages and validation
  - Exit codes for CI/CD integration (0=low, 1=moderate, 2=high/critical)

### Changed
- Updated package.json to include Express.js dependency
- Added `bin/llmverify-serve.js` executable
- Enhanced README with server mode documentation and IDE integration examples
- Improved API response format with consistent structure across all endpoints

### Fixed
- CLI now properly handles `--file` and `--json` flags
- Better error handling for missing or invalid input

### Documentation
- Added comprehensive server mode section to README
- Added IDE integration guide with examples for multiple languages
- Added production deployment best practices
- Added API response format documentation
- Updated CLI usage examples

## [1.0.0] - 2025-12-02

### Added
- Initial release of llmverify
- CSM6 Baseline Profile implementation
- Hallucination risk indicator engine
- Consistency checking engine
- JSON validation engine
- Prompt injection detection (OWASP LLM-01 aligned)
- PII detection (email, phone, SSN, credit cards, API keys)
- Harmful content detection
- CLI tool with text and JSON output
- Privacy guarantees (100% local processing in free tier)
- Confidence intervals on all scores
- Explicit limitations in all results

### Security
- Zero network traffic in free tier
- No telemetry in free tier
- Privacy validation enforced at runtime

### Documentation
- Complete README with examples
- Privacy guarantee documentation
- Accuracy statement and limitations
- CSM6 framework documentation
